import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    console.log("Webhook received:", JSON.stringify(body));

    // MercadoPago sends different notification types
    if (body.type !== "payment" && body.action !== "payment.created" && body.action !== "payment.updated") {
      return new Response(JSON.stringify({ received: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const paymentId = body.data?.id;
    if (!paymentId) {
      return new Response(JSON.stringify({ error: "No payment ID" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const MP_ACCESS_TOKEN = Deno.env.get("MP_ACCESS_TOKEN");
    if (!MP_ACCESS_TOKEN) {
      return new Response(JSON.stringify({ error: "MP not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch payment details from MercadoPago
    const paymentRes = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: { Authorization: `Bearer ${MP_ACCESS_TOKEN}` },
    });
    const payment = await paymentRes.json();
    console.log("Payment status:", payment.status, "external_reference:", payment.external_reference);

    const compraId = payment.external_reference;
    if (!compraId) {
      return new Response(JSON.stringify({ error: "No external reference" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Map MP status to our status
    let estadoPago = "pendiente";
    if (payment.status === "approved") estadoPago = "aprobado";
    else if (payment.status === "rejected") estadoPago = "rechazado";
    else if (payment.status === "cancelled") estadoPago = "rechazado";

    // Update compra
    const { error: updateError } = await supabase
      .from("compras")
      .update({
        estado_pago: estadoPago,
        mp_payment_id: String(paymentId),
      })
      .eq("id", compraId);

    if (updateError) {
      console.error("Error updating compra:", updateError);
    }

    // If approved, generate QR codes (with idempotency check)
    if (estadoPago === "aprobado") {
      // Check if QR codes already exist for this compra (prevents duplicates on webhook retries)
      const { data: existingQrs } = await supabase
        .from("codigos_qr")
        .select("id")
        .eq("compra_id", compraId)
        .limit(1);

      if (existingQrs && existingQrs.length > 0) {
        console.log(`QR codes already exist for compra ${compraId}, skipping generation`);
      } else {
        const { data: compra } = await supabase
          .from("compras")
          .select("cantidad")
          .eq("id", compraId)
          .single();

        if (compra) {
          const qrCodes = Array.from({ length: compra.cantidad }, () => ({
            compra_id: compraId,
          }));

          const { error: qrError } = await supabase.from("codigos_qr").insert(qrCodes);
          if (qrError) {
            console.error("Error creating QR codes:", qrError);
          } else {
            console.log(`Created ${compra.cantidad} QR codes for compra ${compraId}`);
          }
        }
      }
    }

    return new Response(JSON.stringify({ received: true, status: estadoPago }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Webhook error:", err);
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
