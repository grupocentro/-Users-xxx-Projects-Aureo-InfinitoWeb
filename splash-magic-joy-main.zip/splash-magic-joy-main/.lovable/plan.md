# Dashboard Administrativo - Datos en Tiempo Real

## Objetivo

Convertir el Dashboard de `/admin` de valores estaticos (todo en 0) a un panel con datos reales desde la base de datos, incluyendo estadisticas, graficos y actividad reciente.  
necesito que la informacion actual cargada en la web quede cargada en la base de datos y dasboard info e imagenes videos

---

## Que se va a mostrar

### Tarjetas de estadisticas (fila superior)

1. **Ventas Totales** - Suma del campo `total` de compras con `estado_pago = 'aprobado'`
2. **Entradas Hoy** - Cantidad de codigos QR usados hoy (`usado = true` y `usado_at` de hoy)
3. **Eventos Activos** - Count de eventos con `estado = 'activo'`
4. **Atracciones** - Count de atracciones con `estado = 'activo'`

### Grafico de ventas (seccion media)

- Grafico de barras con recharts mostrando ventas aprobadas de los ultimos 7 dias
- Eje X: dias, Eje Y: monto en pesos

### Actividad reciente (seccion inferior)

- Ultimas 10 compras con nombre del cliente, tipo de entrada, monto y estado
- Ultimos 5 QR escaneados hoy con hora y quien lo escaneo

---

## Detalles Tecnicos

### Archivo a modificar

- `src/pages/admin/AdminDashboard.tsx`

### Consultas a la base de datos

Se realizaran 5 queries al montar el componente:

```text
1. compras (estado_pago = 'aprobado') -> sumar total
2. codigos_qr (usado = true, usado_at >= hoy) -> contar
3. eventos (estado = 'activo') -> contar
4. atracciones (estado = 'activo') -> contar
5. compras (ultimos 7 dias, aprobadas) -> para el grafico
6. compras (ultimas 10) -> actividad reciente con join a profiles y tipos_entrada
```

### Grafico

- Se usara `recharts` (ya instalado) con un `BarChart` simple
- Los datos se agruparan por dia usando `date-fns`

### Estructura del componente actualizado

```text
AdminDashboard
  |-- useEffect (fetch all stats on mount)
  |-- 4 Cards de estadisticas (con datos reales)
  |-- Card con BarChart de recharts (ventas ultimos 7 dias)
  |-- Card con tabla de actividad reciente (ultimas compras)
```

### Dependencias

- `recharts` (ya instalado)
- `date-fns` (ya instalado)
- `supabase` client (ya configurado)

No se requieren cambios en la base de datos ni migraciones.   
