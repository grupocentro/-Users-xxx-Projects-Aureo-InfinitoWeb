# CLAUDE.md — Guía maestra para Claude Code

> Este archivo es el punto de entrada para asistentes de IA (Claude Code, Cursor, etc.).
> Leelo primero. Después consultá `docs/` según la tarea.

---

## 1. Resumen del proyecto

**Infinito Water Park** — Sitio web + plataforma de venta de entradas con QR para un parque acuático en Argentina.

- **Dominio productivo**: https://infinito.grupocentro.digital
- **Preview Lovable**: https://splash-magic-joy.lovable.app
- **Repo GitHub**: https://github.com/grupocentro/splash-magic-joy
- **Stack**: React 18 + Vite 5 + TypeScript 5 + Tailwind v3 + shadcn/ui + Supabase (Lovable Cloud) + MercadoPago Sandbox.
- **Idioma**: Español (Argentina). Toda la UI y los mensajes deben estar en español rioplatense.

## 2. Características principales

1. **Sitio público** con secciones: Hero (stories estilo Instagram), Atracciones, Entradas, Mapa, Eventos, Galería.
2. **Compra online de entradas** (`/comprar`) con calendario (febrero 2026) y precios diferenciados semana/finde.
3. **Compra directa de eventos** (sin calendario, sin opción de menores).
4. **Generación de códigos QR únicos** por entrada tras pago aprobado por MercadoPago.
5. **Panel "Mi Cuenta"** (`/mi-cuenta`) donde el cliente ve sus QR y los puede compartir por WhatsApp.
6. **Escáner QR Staff** (`/staff/scanner`) con validación en tiempo real (3 estados: válido / ya usado / inválido).
7. **Panel admin** (`/admin`) con dashboard de métricas, CRUD de contenido, gestión de usuarios y roles, control de tickets.

## 3. Reglas inviolables

- **Diseño**: estética app móvil, paleta water (azul/aqua/blanco), glassmorphism, border-radius 28px, bordes blancos de 5px. Usar SIEMPRE tokens semánticos de `index.css` y `tailwind.config.ts`, NUNCA colores hardcodeados (`text-white`, `bg-blue-500`) en componentes.
- **Assets**: usar imágenes/videos oficiales de infinitowaterpark.com siempre que sea posible.
- **Conversión**: priorizar compra directa a `/comprar`. NO crear links de consulta por WhatsApp para tickets.
- **Roles**: 3 niveles (`admin`, `editor`, `control_entradas`) en tabla `user_roles`, protegidos vía función `has_role()` SECURITY DEFINER. Nunca chequear rol desde localStorage ni desde la tabla `profiles`.
- **Seguridad**: acceso `anon` está explícitamente denegado en `profiles`, `compras`, `user_roles`.
- **No editar nunca**:
  - `src/integrations/supabase/client.ts`
  - `src/integrations/supabase/types.ts`
  - `.env`
  - `supabase/config.toml` (solo bloques de funciones, no settings de proyecto)

## 4. Mapa de rutas

```
/                       Home
/eventos                Listado de eventos
/login                  Login
/registro               Registro (con captcha matemático)
/reset-password         Recuperar contraseña
/comprar                Calendario + compra parque o evento
/compra-exitosa         Confirmación post-pago
/mi-cuenta              Mis tickets (QR + WhatsApp)
/staff/scanner          Escáner QR (rol control_entradas/admin)
/admin                  Layout admin (rol admin/editor)
  ├─ /admin             Dashboard de métricas
  ├─ /admin/eventos
  ├─ /admin/atracciones
  ├─ /admin/actividades
  ├─ /admin/entradas    Tipos de entrada y precios
  ├─ /admin/ventas
  ├─ /admin/contenido   Textos editables del sitio
  ├─ /admin/slides      Hero slides (drag&drop)
  ├─ /admin/usuarios    CRUD usuarios y roles
  └─ /admin/tickets     QR vendidos y escaneados
/aviso-legal, /reglamento, /preguntas-frecuentes,
/terminos-y-condiciones, /politicas-de-privacidad
```

## 5. Base de datos (resumen)

Tablas en `public`: `profiles`, `user_roles`, `atracciones`, `actividades`, `eventos`, `tipos_entrada`, `hero_slides`, `contenido_web`, `compras`, `codigos_qr`.

Detalle completo y RLS → `docs/DATABASE.md`.

Funciones SQL:
- `has_role(_user_id uuid, _role app_role) returns boolean` — SECURITY DEFINER, base de toda autorización.
- `handle_new_user()` — trigger en `auth.users` que crea `profiles` y asigna rol admin a `davidcorreosl@gmail.com`.

Storage buckets: `eventos` (público).

## 6. Edge Functions

- `create-payment` — crea preferencia MercadoPago.
- `webhook-mercadopago` — recibe notificación de pago, verifica idempotencia, marca `compras.estado_pago='aprobado'` y genera N `codigos_qr` (uno por entrada).

Detalle → `docs/EDGE_FUNCTIONS.md`.

## 7. Cuentas de prueba

Ver `docs/CREDENTIALS.md` (NO commitear credenciales reales fuera de ese archivo).

## 8. Documentos detallados

| Archivo | Contenido |
|---|---|
| `docs/ARCHITECTURE.md` | Arquitectura general, stack, decisiones |
| `docs/DATABASE.md` | Esquema completo + RLS por tabla |
| `docs/AUTH_AND_ROLES.md` | Flujo de auth y RBAC |
| `docs/TICKETING_FLOW.md` | Flujo end-to-end de compra y validación QR |
| `docs/ADMIN_PANEL.md` | Cada sección del panel admin |
| `docs/DESIGN_SYSTEM.md` | Tokens, paleta water, glassmorphism, componentes |
| `docs/EDGE_FUNCTIONS.md` | Detalle de cada edge function |
| `docs/CREDENTIALS.md` | Cuentas de prueba Admin/Staff |
| `docs/MERCADOPAGO.md` | Integración Sandbox → Producción |
| `docs/CONVENTIONS.md` | Convenciones de código y commits |

## 9. Workflow recomendado para IA

1. Leer `CLAUDE.md` + el doc específico de la tarea.
2. Verificar tokens de diseño antes de tocar estilos.
3. Para cambios de DB → migración SQL (no editar tipos a mano).
4. Para auth/roles → usar `has_role()` en RLS, nunca lógica cliente.
5. Verificar que la build pasa antes de cerrar la tarea.
