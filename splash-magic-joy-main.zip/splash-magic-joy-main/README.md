# Infinito Water Park

Sitio web y plataforma de venta de entradas con QR para Infinito Water Park.

🌐 **Producción**: https://infinito.grupocentro.digital
🚀 **Preview**: https://splash-magic-joy.lovable.app

## Stack

React 18 · Vite 5 · TypeScript 5 · Tailwind v3 · shadcn/ui · Supabase (Lovable Cloud) · MercadoPago · framer-motion

## Empezar

```bash
bun install
bun run dev
```

## Documentación

Toda la información para entender y modificar el proyecto está en:

- **[CLAUDE.md](./CLAUDE.md)** — Guía maestra (leer primero)
- **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — Arquitectura, stack, decisiones
- **[docs/DATABASE.md](./docs/DATABASE.md)** — Esquema completo + RLS
- **[docs/AUTH_AND_ROLES.md](./docs/AUTH_AND_ROLES.md)** — Autenticación y RBAC
- **[docs/TICKETING_FLOW.md](./docs/TICKETING_FLOW.md)** — Compra → QR → validación
- **[docs/ADMIN_PANEL.md](./docs/ADMIN_PANEL.md)** — Panel administrativo
- **[docs/DESIGN_SYSTEM.md](./docs/DESIGN_SYSTEM.md)** — Tokens, paleta, componentes
- **[docs/EDGE_FUNCTIONS.md](./docs/EDGE_FUNCTIONS.md)** — Funciones serverless
- **[docs/MERCADOPAGO.md](./docs/MERCADOPAGO.md)** — Sandbox → Producción
- **[docs/CONVENTIONS.md](./docs/CONVENTIONS.md)** — Convenciones de código
- **[docs/CREDENTIALS.md](./docs/CREDENTIALS.md)** — Cuentas de prueba

## Características

- 🎟️ Venta online con calendario y precios diferenciados semana/finde
- 🔐 QR único por entrada con validación en tiempo real
- 📱 Escáner para staff con 3 estados visuales
- 👥 RBAC (admin / editor / control_entradas)
- 📊 Dashboard administrativo con métricas
- 💳 MercadoPago integrado (actualmente Sandbox)
- 🎨 Diseño app móvil con paleta water y glassmorphism

## Editar en Lovable

[Abrir proyecto en Lovable](https://lovable.dev/projects/5910aae1-4e95-4ca2-93d1-5037a5fc8d09)

## Sync con GitHub

Sincronización bidireccional. Cambios en Lovable se pushean automáticamente a `grupocentro/splash-magic-joy`. Cambios pusheados al repo se reflejan en Lovable.
