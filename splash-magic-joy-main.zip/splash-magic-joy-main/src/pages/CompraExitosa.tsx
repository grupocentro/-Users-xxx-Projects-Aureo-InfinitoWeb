import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, QrCode, Home } from "lucide-react";

export default function CompraExitosa() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const status = params.get("status");

  if (status === "failure") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">❌</span>
            </div>
            <h1 className="text-2xl font-bold mb-2">Pago no completado</h1>
            <p className="text-muted-foreground mb-6">El pago no se pudo procesar. Podés intentar de nuevo.</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => navigate("/")}>
                <Home className="w-4 h-4 mr-1" /> Inicio
              </Button>
              <Button className="flex-1" onClick={() => navigate("/comprar")}>
                Reintentar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="max-w-md w-full">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold mb-2">¡Compra exitosa! 🎉</h1>
          <p className="text-muted-foreground mb-6">
            Tu pago fue procesado correctamente. Ya podés ver tus códigos QR en tu cuenta.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => navigate("/")}>
              <Home className="w-4 h-4 mr-1" /> Inicio
            </Button>
            <Button className="flex-1" onClick={() => navigate("/mi-cuenta")}>
              <QrCode className="w-4 h-4 mr-1" /> Ver mis QR
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
