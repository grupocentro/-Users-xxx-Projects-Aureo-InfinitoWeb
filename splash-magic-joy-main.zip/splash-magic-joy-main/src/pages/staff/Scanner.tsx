import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Camera, CameraOff, Search, Loader2 } from "lucide-react";

type ScanResult = {
  status: "valid" | "used" | "not_found";
  message: string;
  details?: string;
};

export default function Scanner() {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, isStaff, loading: roleLoading } = useUserRole();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [manualCode, setManualCode] = useState("");
  const [processing, setProcessing] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const scannerRef = useRef<any>(null);

  useEffect(() => {
    if (authLoading || roleLoading) return;
    if (!user) { navigate("/login"); return; }
    if (!isAdmin && !isStaff) { navigate("/"); }
  }, [user, isAdmin, isStaff, authLoading, roleLoading, navigate]);

  const startCamera = async () => {
    try {
      const QrScanner = (await import("qr-scanner")).default;
      if (!videoRef.current) return;

      const scanner = new QrScanner(
        videoRef.current,
        (res) => {
          handleValidate(res.data);
          scanner.stop();
          setScanning(false);
        },
        {
          returnDetailedScanResult: true,
          highlightScanRegion: true,
          highlightCodeOutline: true,
        }
      );

      scannerRef.current = scanner;
      await scanner.start();
      setScanning(true);
      setCameraError(false);
    } catch (err) {
      console.error("Camera error:", err);
      setCameraError(true);
    }
  };

  const stopCamera = () => {
    scannerRef.current?.stop();
    scannerRef.current?.destroy();
    scannerRef.current = null;
    setScanning(false);
  };

  useEffect(() => {
    return () => { scannerRef.current?.destroy(); };
  }, []);

  const handleValidate = async (code: string) => {
    const trimmed = code.trim();
    if (!trimmed) return;

    setProcessing(true);
    setResult(null);

    try {
      // Use service role via edge function or direct query
      const { data: qr, error } = await supabase
        .from("codigos_qr")
        .select("id, uuid_code, usado, usado_at, compra_id")
        .eq("uuid_code", trimmed)
        .maybeSingle();

      if (error) throw error;

      if (!qr) {
        setResult({ status: "not_found", message: "Código no encontrado", details: "Este QR no existe en el sistema." });
      } else if (qr.usado) {
        setResult({
          status: "used",
          message: "QR ya utilizado",
          details: `Usado el ${qr.usado_at ? new Date(qr.usado_at).toLocaleString("es-AR") : "fecha desconocida"}`,
        });
      } else {
        // Mark as used
        const { error: updateError } = await supabase
          .from("codigos_qr")
          .update({ usado: true, usado_at: new Date().toISOString(), usado_por: user?.id })
          .eq("id", qr.id);

        if (updateError) throw updateError;

        setResult({ status: "valid", message: "✅ Entrada válida", details: "QR marcado como utilizado correctamente." });
      }
    } catch (err: any) {
      console.error("Validation error:", err);
      setResult({ status: "not_found", message: "Error", details: err.message });
    } finally {
      setProcessing(false);
    }
  };

  if (authLoading || roleLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const statusColors = {
    valid: "border-green-500 bg-green-50",
    used: "border-destructive bg-red-50",
    not_found: "border-yellow-500 bg-yellow-50",
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <button onClick={() => navigate("/admin")} className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm mb-4">
          <ArrowLeft className="w-4 h-4" /> Volver al panel
        </button>

        <h1 className="text-2xl font-bold mb-1">🔍 Escáner QR</h1>
        <p className="text-sm text-muted-foreground mb-6">Escaneá o ingresá un código para validar la entrada</p>

        {/* Camera */}
        <Card className="mb-4 overflow-hidden">
          <CardContent className="p-0">
            <div className="relative aspect-square bg-muted">
              <video ref={videoRef} className="w-full h-full object-cover" />
              {!scanning && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted">
                  <div className="text-center">
                    {cameraError ? (
                      <>
                        <CameraOff className="w-12 h-12 mx-auto text-muted-foreground/50 mb-2" />
                        <p className="text-sm text-muted-foreground">No se pudo acceder a la cámara</p>
                      </>
                    ) : (
                      <>
                        <Camera className="w-12 h-12 mx-auto text-muted-foreground/50 mb-2" />
                        <p className="text-sm text-muted-foreground">Cámara apagada</p>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="p-3">
              <Button
                className="w-full"
                variant={scanning ? "destructive" : "default"}
                onClick={scanning ? stopCamera : startCamera}
              >
                {scanning ? (
                  <><CameraOff className="w-4 h-4 mr-2" /> Detener cámara</>
                ) : (
                  <><Camera className="w-4 h-4 mr-2" /> Activar cámara</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Manual input */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="text-sm font-medium mb-2">Ingreso manual</p>
            <div className="flex gap-2">
              <Input
                placeholder="Pegá el código UUID aquí"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="font-mono text-sm"
              />
              <Button
                onClick={() => { handleValidate(manualCode); setManualCode(""); }}
                disabled={!manualCode.trim() || processing}
              >
                {processing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Result */}
        {result && (
          <Card className={`border-2 ${statusColors[result.status]}`}>
            <CardContent className="p-6 text-center">
              <p className="text-4xl mb-2">
                {result.status === "valid" ? "✅" : result.status === "used" ? "❌" : "⚠️"}
              </p>
              <p className="text-xl font-bold mb-1">{result.message}</p>
              {result.details && <p className="text-sm text-muted-foreground">{result.details}</p>}
              <Button variant="outline" className="mt-4" onClick={() => setResult(null)}>
                Escanear otro
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
