import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ScanLine, CheckCircle, Clock, Ticket } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface ScanRecord {
  id: string;
  uuid_code: string;
  usado: boolean;
  usado_at: string | null;
  usado_por: string | null;
  compra_id: string;
  tipo: "parque" | "evento";
  tipo_nombre: string;
  scanner_nombre: string;
  cliente_nombre: string;
}

export default function AdminTickets() {
  const [loading, setLoading] = useState(true);
  const [records, setRecords] = useState<ScanRecord[]>([]);
  const [stats, setStats] = useState({
    totalParque: 0,
    totalEventos: 0,
    escaneadosParque: 0,
    escaneadosEventos: 0,
    pendientesParque: 0,
    pendientesEventos: 0,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);

    // Fetch all QR codes with their purchase info
    const { data: qrData } = await supabase
      .from("codigos_qr")
      .select("id, uuid_code, usado, usado_at, usado_por, compra_id")
      .order("usado_at", { ascending: false, nullsFirst: false });

    if (!qrData || qrData.length === 0) {
      setLoading(false);
      return;
    }

    // Get unique compra_ids
    const compraIds = [...new Set(qrData.map((q) => q.compra_id))];
    const { data: compras } = await supabase
      .from("compras")
      .select("id, tipo_entrada_id, evento_id, user_id")
      .in("id", compraIds);

    if (!compras) {
      setLoading(false);
      return;
    }

    // Get related data
    const userIds = [...new Set([
      ...compras.map((c) => c.user_id),
      ...qrData.map((q) => q.usado_por).filter(Boolean),
    ])] as string[];
    
    const tipoIds = [...new Set(compras.map((c) => c.tipo_entrada_id).filter(Boolean))] as string[];
    const eventoIds = [...new Set(compras.map((c) => c.evento_id).filter(Boolean))] as string[];

    const [profilesRes, tiposRes, eventosRes] = await Promise.all([
      userIds.length > 0
        ? supabase.from("profiles").select("id, nombre, apellido").in("id", userIds)
        : Promise.resolve({ data: [] }),
      tipoIds.length > 0
        ? supabase.from("tipos_entrada").select("id, nombre").in("id", tipoIds)
        : Promise.resolve({ data: [] }),
      eventoIds.length > 0
        ? supabase.from("eventos").select("id, nombre").in("id", eventoIds)
        : Promise.resolve({ data: [] }),
    ]);

    const profileMap = new Map((profilesRes.data ?? []).map((p) => [p.id, `${p.nombre} ${p.apellido}`]));
    const tipoMap = new Map((tiposRes.data ?? []).map((t) => [t.id, t.nombre]));
    const eventoMap = new Map((eventosRes.data ?? []).map((e) => [e.id, e.nombre]));
    const compraMap = new Map(compras.map((c) => [c.id, c]));

    const enriched: ScanRecord[] = qrData.map((qr) => {
      const compra = compraMap.get(qr.compra_id);
      const isEvento = !!compra?.evento_id;
      return {
        id: qr.id,
        uuid_code: qr.uuid_code,
        usado: qr.usado,
        usado_at: qr.usado_at,
        usado_por: qr.usado_por,
        compra_id: qr.compra_id,
        tipo: isEvento ? "evento" : "parque",
        tipo_nombre: isEvento
          ? eventoMap.get(compra!.evento_id!) || "Evento"
          : tipoMap.get(compra?.tipo_entrada_id ?? "") || "Entrada",
        scanner_nombre: qr.usado_por ? profileMap.get(qr.usado_por) || "—" : "—",
        cliente_nombre: compra ? profileMap.get(compra.user_id) || "—" : "—",
      };
    });

    setRecords(enriched);

    // Calculate stats
    const parque = enriched.filter((r) => r.tipo === "parque");
    const eventos = enriched.filter((r) => r.tipo === "evento");
    setStats({
      totalParque: parque.length,
      totalEventos: eventos.length,
      escaneadosParque: parque.filter((r) => r.usado).length,
      escaneadosEventos: eventos.filter((r) => r.usado).length,
      pendientesParque: parque.filter((r) => !r.usado).length,
      pendientesEventos: eventos.filter((r) => !r.usado).length,
    });

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const renderTable = (data: ScanRecord[]) => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Estado</TableHead>
          <TableHead>Tipo</TableHead>
          <TableHead>Cliente</TableHead>
          <TableHead>Código</TableHead>
          <TableHead>Escaneado por</TableHead>
          <TableHead>Hora escaneo</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.length === 0 ? (
          <TableRow>
            <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
              No hay registros
            </TableCell>
          </TableRow>
        ) : (
          data.map((r) => (
            <TableRow key={r.id}>
              <TableCell>
                {r.usado ? (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="w-3 h-3 mr-1" /> Escaneado
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                    <Clock className="w-3 h-3 mr-1" /> Pendiente
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                <span className="text-sm font-medium">{r.tipo_nombre}</span>
              </TableCell>
              <TableCell className="font-medium">{r.cliente_nombre}</TableCell>
              <TableCell>
                <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                  {r.uuid_code.slice(0, 8)}…
                </code>
              </TableCell>
              <TableCell>{r.scanner_nombre}</TableCell>
              <TableCell className="text-muted-foreground text-sm">
                {r.usado_at
                  ? format(new Date(r.usado_at), "dd/MM/yy HH:mm", { locale: es })
                  : "—"}
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );

  const parqueRecords = records.filter((r) => r.tipo === "parque");
  const eventoRecords = records.filter((r) => r.tipo === "evento");

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">🎟️ Tickets & Escaneos</h1>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Escaneados Parque</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.escaneadosParque}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalParque} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pendientes Parque</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendientesParque}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Escaneados Eventos</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.escaneadosEventos}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalEventos} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pendientes Eventos</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendientesEventos}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for parque vs eventos */}
      <Card>
        <CardContent className="p-0">
          <Tabs defaultValue="todos" className="w-full">
            <div className="px-4 pt-4">
              <TabsList>
                <TabsTrigger value="todos">
                  <ScanLine className="w-4 h-4 mr-1.5" /> Todos ({records.length})
                </TabsTrigger>
                <TabsTrigger value="parque">
                  <Ticket className="w-4 h-4 mr-1.5" /> Parque ({parqueRecords.length})
                </TabsTrigger>
                <TabsTrigger value="eventos">
                  🎉 Eventos ({eventoRecords.length})
                </TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="todos" className="mt-0">
              {renderTable(records)}
            </TabsContent>
            <TabsContent value="parque" className="mt-0">
              {renderTable(parqueRecords)}
            </TabsContent>
            <TabsContent value="eventos" className="mt-0">
              {renderTable(eventoRecords)}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
