import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Eventos from "./pages/Eventos";
import Login from "./pages/Login";
import Registro from "./pages/Registro";
import ResetPassword from "./pages/ResetPassword";
import Comprar from "./pages/Comprar";
import CompraExitosa from "./pages/CompraExitosa";
import MiCuenta from "./pages/MiCuenta";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminEventos from "./pages/admin/AdminEventos";
import AdminAtracciones from "./pages/admin/AdminAtracciones";
import AdminSlides from "./pages/admin/AdminSlides";
import AdminActividades from "./pages/admin/AdminActividades";
import AdminEntradas from "./pages/admin/AdminEntradas";
import AdminVentas from "./pages/admin/AdminVentas";
import AdminContenido from "./pages/admin/AdminContenido";
import AdminUsuarios from "./pages/admin/AdminUsuarios";
import AdminTickets from "./pages/admin/AdminTickets";
import Scanner from "./pages/staff/Scanner";
import NotFound from "./pages/NotFound";
import AvisoLegal from "./pages/legal/AvisoLegal";
import Reglamento from "./pages/legal/Reglamento";
import PreguntasFrecuentes from "./pages/legal/PreguntasFrecuentes";
import TerminosCondiciones from "./pages/legal/TerminosCondiciones";
import PoliticasPrivacidad from "./pages/legal/PoliticasPrivacidad";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/eventos" element={<Eventos />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registro" element={<Registro />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/comprar" element={<Comprar />} />
          <Route path="/compra-exitosa" element={<CompraExitosa />} />
          <Route path="/mi-cuenta" element={<MiCuenta />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="eventos" element={<AdminEventos />} />
            <Route path="atracciones" element={<AdminAtracciones />} />
            <Route path="actividades" element={<AdminActividades />} />
            <Route path="entradas" element={<AdminEntradas />} />
            <Route path="ventas" element={<AdminVentas />} />
            <Route path="contenido" element={<AdminContenido />} />
            <Route path="slides" element={<AdminSlides />} />
            <Route path="usuarios" element={<AdminUsuarios />} />
            <Route path="tickets" element={<AdminTickets />} />
          </Route>
          <Route path="/staff/scanner" element={<Scanner />} />
          <Route path="/aviso-legal" element={<AvisoLegal />} />
          <Route path="/reglamento" element={<Reglamento />} />
          <Route path="/preguntas-frecuentes" element={<PreguntasFrecuentes />} />
          <Route path="/terminos-y-condiciones" element={<TerminosCondiciones />} />
          <Route path="/politicas-de-privacidad" element={<PoliticasPrivacidad />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
